create
    definer = root@localhost procedure AddToCart(IN _kundid int, IN _bestid int, IN _skoid int)
BEGIN
	declare finnsBest INT default 0;                    
	declare finnsSko INT default 0;                     
	declare skoAmount INT default 0;                    
	declare kostnad INT default 0;				        
    
	declare exit handler for sqlexception
    begin
		rollback;
        resignal set message_text = 'Sql exception occured';
    end;
	
	select count(*) into finnsBest from beställning where beställning.id = _bestid;

	select count(innehåller.skoid) into finnsSko
	from innehåller
	join beställning
	on innehåller.bestid = beställning.id
	where beställning.id = _bestid and innehåller.skoid = _skoid;

	select finns_i.antal into skoAmount 
	from finns_i
	where skoid = _skoid;
    
	select skor.pris into kostnad
    from skor
    where skor.id = _skoid;
    
	if finnsBest = 0 or _bestid is null then
		set autocommit = 0; 
        start transaction;
			insert into beställning (total, datum, kundid) 
			values (kostnad, now(), _kundid); 
			insert into innehåller (antal, skoid, bestid) 
			values (1, _skoid, last_insert_id());
        commit;
        set autocommit = 1;

	elseif finnsBest > 0 then 
		if finnsSko > 0 then
			UPDATE innehåller 
			SET antal = antal + 1 
			WHERE bestid = _bestid and skoid = _skoid;
		else
			insert into innehåller (antal, skoid, bestid)
			values (1, _skoid, _bestid);
		end if;
		update beställning 
		set total = total + kostnad
		where beställning.id = _bestid;
	end if;

	if skoAmount > 0 then
		UPDATE finns_i 
		SET antal = antal - 1 
		WHERE skoid = _skoid;
	end if; 
END;

